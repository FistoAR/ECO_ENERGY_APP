<?php
class Expo {
    private $conn;
    private $table = 'expos';
    private $dates_table = 'expo_dates';

    public $id;
    public $name;
    public $location;
    public $status;
    public $dates;
    public $created_at;
    public $updated_at;

    public function __construct($db) {
        $this->conn = $db;
    }

    // Get all expos with their dates
    public function getAll($page = 1, $limit = 10, $search = '') {
        $offset = ($page - 1) * $limit;
        
        // Build search condition
        $searchCondition = '';
        $params = [];
        
        if (!empty($search)) {
            $searchCondition = "WHERE e.name LIKE :search OR e.location LIKE :search2";
            $params[':search'] = "%$search%";
            $params[':search2'] = "%$search%";
        }

        // Get total count
        $countQuery = "SELECT COUNT(*) as total FROM " . $this->table . " e " . $searchCondition;
        $countStmt = $this->conn->prepare($countQuery);
        
        foreach ($params as $key => $value) {
            $countStmt->bindValue($key, $value);
        }
        
        $countStmt->execute();
        $totalItems = $countStmt->fetch(PDO::FETCH_ASSOC)['total'];

        // Get expos
        $query = "SELECT e.* FROM " . $this->table . " e " . $searchCondition . 
                 " ORDER BY e.created_at DESC LIMIT :limit OFFSET :offset";
        
        $stmt = $this->conn->prepare($query);
        
        foreach ($params as $key => $value) {
            $stmt->bindValue($key, $value);
        }
        
        $stmt->bindValue(':limit', (int)$limit, PDO::PARAM_INT);
        $stmt->bindValue(':offset', (int)$offset, PDO::PARAM_INT);
        $stmt->execute();

        $expos = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $row['dates'] = $this->getExpoDates($row['id']);
            $expos[] = $row;
        }

        return [
            'data' => $expos,
            'pagination' => [
                'current_page' => (int)$page,
                'per_page' => (int)$limit,
                'total_items' => (int)$totalItems,
                'total_pages' => ceil($totalItems / $limit)
            ]
        ];
    }

    // Get expo dates
    private function getExpoDates($expoId) {
        $query = "SELECT event_date FROM " . $this->dates_table . 
                 " WHERE expo_id = :expo_id ORDER BY event_date ASC";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':expo_id', $expoId);
        $stmt->execute();

        $dates = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $dates[] = $row['event_date'];
        }

        return $dates;
    }

    // Get single expo
    public function getById($id) {
        $query = "SELECT * FROM " . $this->table . " WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $id);
        $stmt->execute();

        $expo = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($expo) {
            $expo['dates'] = $this->getExpoDates($expo['id']);
        }

        return $expo;
    }

    // Create expo
    public function create() {
        try {
            $this->conn->beginTransaction();

            // Insert expo
            $query = "INSERT INTO " . $this->table . " (name, location, status) 
                      VALUES (:name, :location, :status)";
            
            $stmt = $this->conn->prepare($query);
            
            // Sanitize
            $this->name = htmlspecialchars(strip_tags($this->name));
            $this->location = htmlspecialchars(strip_tags($this->location));
            $this->status = htmlspecialchars(strip_tags($this->status));

            $stmt->bindParam(':name', $this->name);
            $stmt->bindParam(':location', $this->location);
            $stmt->bindParam(':status', $this->status);
            
            $stmt->execute();
            $this->id = $this->conn->lastInsertId();

            // Insert dates
            if (!empty($this->dates) && is_array($this->dates)) {
                $this->insertDates($this->id, $this->dates);
            }

            $this->conn->commit();
            return true;
        } catch (Exception $e) {
            $this->conn->rollBack();
            throw $e;
        }
    }

    // Insert expo dates
    private function insertDates($expoId, $dates) {
        $query = "INSERT INTO " . $this->dates_table . " (expo_id, event_date) VALUES (:expo_id, :event_date)";
        $stmt = $this->conn->prepare($query);

        foreach ($dates as $date) {
            $stmt->bindParam(':expo_id', $expoId);
            $stmt->bindParam(':event_date', $date);
            $stmt->execute();
        }
    }

    // Delete expo dates
    private function deleteDates($expoId) {
        $query = "DELETE FROM " . $this->dates_table . " WHERE expo_id = :expo_id";
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':expo_id', $expoId);
        $stmt->execute();
    }

    // Update expo
    public function update() {
        try {
            $this->conn->beginTransaction();

            $query = "UPDATE " . $this->table . " 
                      SET name = :name, location = :location, status = :status 
                      WHERE id = :id";
            
            $stmt = $this->conn->prepare($query);
            
            // Sanitize
            $this->name = htmlspecialchars(strip_tags($this->name));
            $this->location = htmlspecialchars(strip_tags($this->location));
            $this->status = htmlspecialchars(strip_tags($this->status));
            $this->id = htmlspecialchars(strip_tags($this->id));

            $stmt->bindParam(':name', $this->name);
            $stmt->bindParam(':location', $this->location);
            $stmt->bindParam(':status', $this->status);
            $stmt->bindParam(':id', $this->id);
            
            $stmt->execute();

            // Update dates - delete old and insert new
            $this->deleteDates($this->id);
            
            if (!empty($this->dates) && is_array($this->dates)) {
                $this->insertDates($this->id, $this->dates);
            }

            $this->conn->commit();
            return true;
        } catch (Exception $e) {
            $this->conn->rollBack();
            throw $e;
        }
    }

    // Delete expo
    public function delete() {
        $query = "DELETE FROM " . $this->table . " WHERE id = :id";
        
        $stmt = $this->conn->prepare($query);
        $stmt->bindParam(':id', $this->id);
        
        return $stmt->execute();
    }

    // Validate expo data
    public function validate() {
        $errors = [];

        if (empty($this->name)) {
            $errors['name'] = 'Expo name is required';
        }

        if (empty($this->location)) {
            $errors['location'] = 'Location is required';
        }

        if (empty($this->dates) || !is_array($this->dates) || count($this->dates) === 0) {
            $errors['dates'] = 'At least one date is required';
        }

        $validStatuses = ['active', 'upcoming', 'completed'];
        if (!in_array($this->status, $validStatuses)) {
            $errors['status'] = 'Invalid status';
        }

        return $errors;
    }
}
?>