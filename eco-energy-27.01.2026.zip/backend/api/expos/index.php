<?php
header('Access-Control-Allow-Origin: *');
header('Content-Type: application/json');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Handle preflight requests
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

require_once '../../config/database.php';
require_once '../../models/Expo.php';
require_once '../../helpers/Response.php';

$database = new Database();
$db = $database->getConnection();
$expo = new Expo($db);

$method = $_SERVER['REQUEST_METHOD'];

// Get ID from URL if present
$id = isset($_GET['id']) ? $_GET['id'] : null;

switch ($method) {
    case 'GET':
        if ($id) {
            // Get single expo
            $result = $expo->getById($id);
            
            if ($result) {
                Response::success($result, 'Expo retrieved successfully');
            } else {
                Response::error('Expo not found', 404);
            }
        } else {
            // Get all expos with pagination
            $page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
            $limit = isset($_GET['limit']) ? (int)$_GET['limit'] : 10;
            $search = isset($_GET['search']) ? $_GET['search'] : '';
            
            $result = $expo->getAll($page, $limit, $search);
            Response::success($result, 'Expos retrieved successfully');
        }
        break;

    case 'POST':
        $data = json_decode(file_get_contents("php://input"));
        
        if (!$data) {
            Response::error('Invalid JSON data', 400);
        }

        $expo->name = $data->name ?? '';
        $expo->location = $data->location ?? '';
        $expo->status = $data->status ?? 'upcoming';
        $expo->dates = $data->dates ?? [];

        // Validate
        $errors = $expo->validate();
        if (!empty($errors)) {
            Response::error('Validation failed', 422, $errors);
        }

        try {
            if ($expo->create()) {
                $newExpo = $expo->getById($expo->id);
                Response::success($newExpo, 'Expo created successfully', 201);
            }
        } catch (Exception $e) {
            Response::error('Failed to create expo: ' . $e->getMessage(), 500);
        }
        break;

    case 'PUT':
        if (!$id) {
            Response::error('Expo ID is required', 400);
        }

        // Check if expo exists
        $existingExpo = $expo->getById($id);
        if (!$existingExpo) {
            Response::error('Expo not found', 404);
        }

        $data = json_decode(file_get_contents("php://input"));
        
        if (!$data) {
            Response::error('Invalid JSON data', 400);
        }

        $expo->id = $id;
        $expo->name = $data->name ?? '';
        $expo->location = $data->location ?? '';
        $expo->status = $data->status ?? 'upcoming';
        $expo->dates = $data->dates ?? [];

        // Validate
        $errors = $expo->validate();
        if (!empty($errors)) {
            Response::error('Validation failed', 422, $errors);
        }

        try {
            if ($expo->update()) {
                $updatedExpo = $expo->getById($id);
                Response::success($updatedExpo, 'Expo updated successfully');
            }
        } catch (Exception $e) {
            Response::error('Failed to update expo: ' . $e->getMessage(), 500);
        }
        break;

    case 'DELETE':
        if (!$id) {
            Response::error('Expo ID is required', 400);
        }

        // Check if expo exists
        $existingExpo = $expo->getById($id);
        if (!$existingExpo) {
            Response::error('Expo not found', 404);
        }

        $expo->id = $id;

        try {
            if ($expo->delete()) {
                Response::success(null, 'Expo deleted successfully');
            }
        } catch (Exception $e) {
            Response::error('Failed to delete expo: ' . $e->getMessage(), 500);
        }
        break;

    default:
        Response::error('Method not allowed', 405);
        break;
}
?>